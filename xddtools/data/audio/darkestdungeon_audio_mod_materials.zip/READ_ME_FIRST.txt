Hey Darkest Dungeon Modders!

Before you get started:

1. Download FMOD Studio.

Win: http://www.fmod.org/download/fmodstudio/tool/Win/fmodstudio10607win-installer.exe

Mac: http://www.fmod.org/download/fmodstudio/tool/Mac/fmodstudio10607mac-installer.dmg


2. Download a source code editor such as Notepad++: https://notepad-plus-plus.org/


Once you do that, you should be ready to dive in to the FMOD Studio project file.
We've prepared a very quick tutorial for you, located inside the project file,
in the Properties Pane of all events inside the "MODDERS_READ_ME_FIRST" folder.


If you need help with anything further, feel free to join and contribute to the 
Darkest Dungeon - Workshop group on Steam: http://steamcommunity.com/groups/dd-workshop


Happy modding!

~~~~~~~~~~~~~~~~~~~~
Kevin Regamey
Power Up Audio
www.powerupaudio.com